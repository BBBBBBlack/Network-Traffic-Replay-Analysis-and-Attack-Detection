from flask import Flask, request, jsonify
import requests
import json
import subprocess
import os

# 当检测到重流时，传入重流的{"ip_src": "10.0.0.1", "ip_dst": "10.0.0.3", "tp_src": "81", "tp_dst": "80"}这些字段即可添加丢弃的流表项>，丢弃该数据包。
def addflow(flow1):
    url = 'http://127.0.0.1:8080/stats/flowentry/add'
    flow = {
        "dpid": flow1["dpid"],
        "cookie": 1,
        "table_id": 0,
        "idle_timeout": 3000,
        "hard_timeout": 3000,
        "priority": 1111,
        "flags": 1,
        "match": {
            "dl_type": 0x0800,
            "nw_src": flow1["ip_src"],
            "nw_dst": flow1["ip_dst"],
            "nw_proto": flow1["proto"],
            "tp_src": flow1["tp_src"],
            "tp_dst": flow1["tp_dst"]
        },
        "actions": {

        }
    }

    headers = {'Content-Type': 'application/json'}
    response = requests.post(url, json=flow)
    if response.status_code == 200:
        print("流表项添加成功！")
        # 在这里可以进一步处理响应结果或执行其他操作
        return True
    else:
        print("流表项添加失败！")
        print(response.status_code)
        print(response.text)
        return False


app = Flask(__name__)

@app.route('/intercept_flow', methods=['POST'])
def receive_data():
    data = request.get_json()
    if addflow(data):
        return '流表项添加成功！'
    # 对接收到的数据进行处理
    return '流表项添加失败！'

@app.route('/read_json', methods=['POST'])
def read_json():
    try:
        with open('classes/json', 'r') as file:
            file_content = json.load(file)  # 读取文件内容
            return jsonify(file_content)  # 返回json格式的文件内容
    except Exception as e:
        return jsonify({'error': str(e)}), 400  # 如果出现错误，返回错误信息和状态码400


@app.route('/get_hitter', methods=['POST'])
def get_hitter():
    # os.chdir('/root/projects/MVSketch/bin/x64/Debug')
    data = request.get_json()
    res=subprocess.run(['./MVSketch.out', data["k"], '0'], capture_output=True, text=True)
    return res.stdout

@app.route('/get_flow_count', methods=['POST'])
def get_flow_count():
    # os.chdir('/root/projects/MVSketch/bin/x64/Debug')
    res=subprocess.run(['./MVSketch.out', '1', '1'], capture_output=True, text=True)
    return res.stdout
    
if __name__ == '__main__':
    app.run(debug=True,host='172.26.62.72',port=8888)
