from scapy.all import *
import socket
import time

ip_list = ['10.0.0.0', '10.0.0.2', '10.0.0.1', '10.0.0.4', '10.0.0.5', '10.0.0.6',
           '10.0.0.7']  # 不包含本机IP,this ip is 10.0.0.3
hostname = socket.gethostname()
ip = socket.gethostbyname(hostname)  # fetch the ip Address

def create_TCP():
    pkt1 = IP()/TCP()
    pkt1.src = ip  # set源IP Address
    pkt1.dst = random.choice(ip_list)  # set目标IP Address
    pkt1.sport = 13326  # set源port
    pkt1.dport = 443  # set目标port
    send(pkt1)
def create_UDP():
    pkt2 = IP()/UDP(sport=61576,dport=32048)
    pkt2.src = ip  # set源IP Address
    pkt2.dst = random.choice(ip_list)  # set目标IP Address
    send(pkt2)
def create_ICMP():
    pkt3 = IP()/ICMP(type=8)
    pkt3.src = ip
    pkt3.dst = random.choice(ip_list)
    send(pkt3)


def main():
    functions = [create_UDP,create_TCP,create_ICMP]

    while(1):
        random_function = random.choice(functions)
        random_function()
        time.sleep(0.1)

if __name__ == '__main__':
	main()
