from mininet.topo import Topo
from mininet.node import OVSBridge

class MyTopo(Topo):
    def __init__(self):
        Topo.__init__(self)
        h = []
        for i in range(8):
            h.append('h' + str(i + 1))
            self.addHost(h[i])
        s = []
        for i in range(8):
            s.append('s' + str(i + 1))
            self.addSwitch(s[i],stp=True)
        layer_num = [2, 2, 4]
        cnt = 0
        # s5,s6,s7,s8s
        for i in range(layer_num[2]):
            self.addLink(h[cnt], s[layer_num[0] + layer_num[1] + i])
            cnt += 1
            self.addLink(h[cnt], s[layer_num[0] + layer_num[1] + i])
            cnt += 1
        # s3,s4
        for i in range(layer_num[1]):
            for j in range(layer_num[2]):
                self.addLink(s[layer_num[0] + i], s[layer_num[0] + layer_num[1] + j])
        self.addLink(s[2],s[3])
        # s1,s2
        for i in range(layer_num[0]):
            for j in range(layer_num[1]):
                self.addLink(s[i],s[layer_num[0]+j])
        self.addLink(s[0],s[1])
topos = {'mytopo': (lambda: MyTopo())}
