import torch
import os

from matplotlib import pyplot as plt

from preprocess.preprocess import preprocess
from cnn.cnn import CNN
from train.train import train
from test.test import test


def loss_value_plot(losses, iter):
    plt.figure()
    plt.plot([i for i in range(1, iter + 1)], losses)
    plt.xlabel('Iterations (×100)')
    plt.ylabel('Loss Value')


def main():
    train_data, test_data, X_dimension, y_dimension, train_loader, test_loader = preprocess()
    # 使用cuda进行GPU加速，如果无可加速显卡，则使用cpu
    device = 'cuda:0' if torch.cuda.is_available() else 'cpu'
    # 加载模型
    cnn_model = CNN(X_dimension, y_dimension)
    cnn_model.to(device=device)
    optimizer = torch.optim.Adam(cnn_model.parameters(), lr=0.001)
    loss_fn = torch.nn.CrossEntropyLoss()
    if os.path.exists('model/CNN_model.pth'):
        cnn_model.load_state_dict(torch.load('model/CNN_model.pth'))
    else:

        epochs = 1
        losses, iter = train(cnn_model, optimizer, loss_fn, epochs, X_dimension, train_loader, train_data, device)
        torch.save(cnn_model.state_dict(), 'model/cnn_model.pth')

        loss_value_plot(losses, iter)
        plt.savefig('model/cnn_loss.png')
    test(cnn_model, test_loader, X_dimension, loss_fn, device)


if __name__ == '__main__':
    main()
