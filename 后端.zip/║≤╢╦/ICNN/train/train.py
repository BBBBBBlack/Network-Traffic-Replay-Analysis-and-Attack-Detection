import torch
from cnn.cnn import CNN
from preprocess.preprocess import preprocess


def train(model, optimizer, loss_fn, epochs, X_dimension, train_loader, train_data, device):
    losses = []
    iter = 0

    for epoch in range(epochs):
        print(f"epoch {epoch + 1}\n-----------------")
        for i, (X, y) in enumerate(train_loader):
            X, y = X.to(device).to(torch.float32), y.to(device).to(torch.float32)  # (128,78)
            X = X.reshape(X.shape[0], 1, X_dimension)
            y_pred = model(X)  # (128,15)
            # y_pred = y_pred.transpose(0, 1)
            y_pred = y_pred.to(torch.float32)
            y = y.to(torch.float32)
            loss = loss_fn(y_pred, y.long())
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            if i % 100 == 0:
                print(f"loss: {loss.item()}\t[{(i + 1) * len(X)}/{len(train_data)}]")

                iter += 1
                losses.append(loss.item())

    return losses, iter
