import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader
from cnn.cnn import CNN
from preprocess.load_data import LoadData
from preprocess.numberical_data import encode_numeric_range
from preprocess.numberical_data import encode_numeric_zscore

# 加载模型
classes_map = ['BENIGN', 'Bot', 'DDoS', 'DoS GoldenEye', 'DoS Hulk', 'DoS Slowhttptest',
               'DoS slowloris', 'FTP-Patator', 'Heartbleed', 'Infiltration', 'PortScan',
               'SSH-Patator', 'Web Attack � Brute Force', 'Web Attack � Sql Injection',
               'Web Attack � XSS']

device = 'cuda:0' if torch.cuda.is_available() else 'cpu'
# 加载模型
cnn_model = CNN(78, 15)
cnn_model.to(device=device)
cnn_model.load_state_dict(torch.load('/SDN/flask/ICNN/model/cnn_model.pth',map_location=torch.device('cpu')))
df = pd.read_csv('/SDN/flask/csv/trace1.pcap_Flow.csv', encoding='utf8', header=None, low_memory=False)
df = df.loc[1:, :]
tuple5 = df.iloc[:, 0:6]  # 五元组
df = pd.concat([df.loc[:, 4], df.loc[:, 7:60], df.loc[:, 40], df.loc[:, 61:82]], axis=1)
df = pd.DataFrame(df, dtype=float)
df.columns = range(len(df.columns))

y_pred_list = []
df = encode_numeric_zscore(df, df.columns)
df = encode_numeric_range(df, df.columns)
invalid_mask = np.isnan(df) | np.isinf(df)
valid_rows = ~np.any(invalid_mask, axis=1)
df = pd.DataFrame([df.iloc[i, :] for i in range(len(df)) if valid_rows[i + 1]])
tuple5 = pd.DataFrame([tuple5.iloc[i, :] for i in range(len(tuple5)) if valid_rows[i + 1]])
y_data = pd.DataFrame([0] * len(df)).squeeze()
test_data = LoadData(df.iloc[:, :], y_data)

test_dataloader = DataLoader(test_data, batch_size=1)
X_dimension = len(df.iloc[:, :].columns)
records = None
for i, (X, y) in enumerate(test_dataloader):
    X = X.to(device).to(torch.float32)
    X = X.reshape(X.shape[0], 1, X_dimension)
    y_pred = cnn_model(X)
    y_pred_softmax = F.softmax(y_pred, dim=1)
    predicted_labels = torch.argmax(y_pred_softmax, dim=1)
    predicted_labels = [classes_map[idx.item()] for idx in predicted_labels]
    y_pred_list.append(predicted_labels[0])

    # 获取对应的tuple5
    if predicted_labels[0] != 'BENIGN':
        current_tuple5 = tuple5.iloc[i, :]
        # print("Predicted label:", predicted_labels[0])
        # print("Corresponding tuple5:", current_tuple5)
        temp = pd.DataFrame({0: current_tuple5})
        temp2 = pd.DataFrame({0: [predicted_labels[0]]})
        record = temp2[0].append(temp[0])
        record = pd.DataFrame(record).transpose()
        record.columns = ['type', 'flow_id', 'src_ip', 'src_port', 'dst_ip', 'dst_port', 'protocol']
        if records is None:
            records = record
            records.columns = ['type', 'flow_id', 'src_ip', 'src_port', 'dst_ip', 'dst_port', 'protocol']
        else:
            records = records.append(record)
records.reset_index([i in range(len(records))], drop=True, inplace=True)
records.to_json("json", orient="records")
