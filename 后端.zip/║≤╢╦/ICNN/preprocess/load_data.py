import torch
from torch.utils.data import Dataset
from torch.utils.data import DataLoader
from sklearn.model_selection import train_test_split


class LoadData(Dataset):
    def __init__(self, X, y):
        self.X = X
        self.y = y

    def __len__(self):
        return len(self.X)

    def __getitem__(self, index):
        X = None
        y = None
        if self.X is not None:
            X = torch.tensor(self.X.iloc[index])
        if self.y is not None:
            y = torch.tensor(self.y.iloc[index])
        return X, y


def dataLoader(df):
    X = df.drop(columns=['Label'])
    y = df['Label']
    # 训练集，测试集
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.20, random_state=50)
    X_dimension = len(X_train.columns)
    y_dimension = len(y_train.value_counts())
    train_data = LoadData(X_train, y_train)
    test_data = LoadData(X_test, y_test)
    batch_size = 128
    train_dataloader = DataLoader(train_data, batch_size=batch_size)
    test_dataloader = DataLoader(test_data, batch_size=batch_size)
    return train_data, test_data, X_dimension, y_dimension, train_dataloader, test_dataloader
