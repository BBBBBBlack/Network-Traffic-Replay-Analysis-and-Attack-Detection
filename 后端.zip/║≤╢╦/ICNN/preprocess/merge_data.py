import pandas as pd


# 根据file读取数据
def writeData(file):
    print("Loading raw data...")
    raw_data = pd.read_csv(file, header=None, low_memory=False)
    # 剔除第一行属性特征名称
    return raw_data.drop([0])


# 按行合并多个Dataframe数据
def mergeData():
    monday = writeData(
        "D:/course/pythonnn/DAMO/ICNN/preprocess/data/MachineLearningCVE/"
        "Monday-WorkingHours.pcap_ISCX.csv")

    friday1 = writeData(
        "D:/course/pythonnn/DAMO/ICNN/preprocess/data/MachineLearningCVE/"
        "Friday-WorkingHours-Afternoon-DDos.pcap_ISCX.csv")

    friday2 = writeData(
        "D:/course/pythonnn/DAMO/ICNN/preprocess/data/MachineLearningCVE/"
        "Friday-WorkingHours-Afternoon-PortScan.pcap_ISCX.csv")

    friday3 = writeData(
        "D:/course/pythonnn/DAMO/ICNN/preprocess/data/MachineLearningCVE/"
        "Friday-WorkingHours-Morning.pcap_ISCX.csv")

    thursday1 = writeData(
        "D:/course/pythonnn/DAMO/ICNN/preprocess/data/MachineLearningCVE/"
        "Thursday-WorkingHours-Afternoon-Infilteration.pcap_ISCX.csv")

    thursday2 = writeData(
        "D:/course/pythonnn/DAMO/ICNN/preprocess/data/MachineLearningCVE/"
        "Thursday-WorkingHours-Morning-WebAttacks.pcap_ISCX.csv")

    tuesday = writeData(
        "D:/course/pythonnn/DAMO/ICNN/preprocess/data/MachineLearningCVE/"
        "Tuesday-WorkingHours.pcap_ISCX.csv")

    wednesday = writeData(
        "D:/course/pythonnn/DAMO/ICNN/preprocess/data/MachineLearningCVE/"
        "Wednesday-workingHours.pcap_ISCX.csv")

    frame = [monday, friday1, friday2, friday3, thursday1, thursday2, tuesday, wednesday]

    # 合并数据
    result = pd.concat(frame)  # (2830743,79)
    list = clearDirtyData(result)  # 2867
    result = result.drop(list)
    return result  # (2813797)


def mergeData2(path):
    result = writeData(path)
    list = clearDirtyData(result)  # 2867
    result = result.drop(list)
    return result


# 清除CIC-IDS数据集中的脏数据，第一行特征名称和含有Nan、Infinity等数据的行数
def clearDirtyData(df):
    return df[(df[14] == "Nan") | (df[15] == "Infinity")].index.tolist()
