import pandas as pd
from sklearn.model_selection import train_test_split
import torch
import preprocess.merge_data as merge_data
import preprocess.expend_data as expend_data
import preprocess.numberical_data as numberical_data
import preprocess.load_data as load_data
from cnn.cnn import CNN


def preprocess():
    # raw_data = merge_data.mergeData()
    # lists = expend_data.separateData(raw_data)
    # expend_data.expendData(raw_data, lists)
    df = pd.read_csv('D:\\course\\pythonnn\\DAMO\\ICNN\\preprocess\\data\\clearData\\total_extend.csv', header=None,
                     low_memory=False)
    df = numberical_data.process(df)  # (2848299, 79)
    train_data, test_data, X_dimension, y_dimension, train_loader, test_loader = load_data.dataLoader(
        df)  # train_X.shape:(2278639,78) test_X.shape:(569660,78)
    return train_data, test_data, X_dimension, y_dimension, train_loader, test_loader
