import torch
from torch import nn


class CNN(nn.Module):
    def __init__(self, X_dimension, y_dimension):
        self.X_dimension = X_dimension
        self.y_dimension = y_dimension
        super().__init__()
        self.backbone = nn.Sequential(
            nn.Conv1d(1, 32, kernel_size=2),
            nn.Conv1d(32, 64, kernel_size=2),
            nn.MaxPool1d(2, 2),
            nn.Conv1d(64, 64, kernel_size=2),
            nn.Conv1d(64, 128, kernel_size=2),
            nn.MaxPool1d(2, 2),
        )
        self.flatten = nn.Flatten()
        self.fc = nn.Sequential(
            nn.Linear(2304, 64),
            nn.ReLU(),
            nn.Linear(64, 64),
            nn.ReLU(),
            nn.Linear(64, self.y_dimension)
        )

    def forward(self, X):
        X = self.backbone(X)
        X = self.flatten(X)
        logits = self.fc(X)
        return logits

