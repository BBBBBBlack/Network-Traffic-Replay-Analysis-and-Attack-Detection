* 目录结构

  * interface.py        flask接口程序
  * simple_test.py   流量攻击类型检测程序
  * MVSketch.out    MV-Sketch的可执行文件
  * MVSketch           MVSketch算法具体实现
  * mytopo.py         拓扑构建脚本
  * classes                cicflowmeter工具，可将pcap文件提取出特征信息，以csv文件形式存储
    * catch.py    抓包程序
  * ICNN                   神经网络训练及测试代码
    * cnn           神经网络
    * model      训练好的神经网络模型
    * preprocess  预处理程序
    * test           CIC-IDS-2017测试集测试程序
    * train          模型训练程序
  * total.py                模型训练及测试集精度判断
  * jar                         cicflowmeter运行所需jar包
  * pcap                     pcap抓包获取的.pcap文件
  * csv                        cicflowmeter转换的.csv文件

* 部署方法

  * 启动RYU控制器，执行命令：

    ```
    ryu-manager ryu/ryu/app/simple_switch_stp_13.py   ryu/ryu/app/ofctl_rest.py ryu/ryu/app/rest_topology.py
    ```

  * 构建拓扑

    ````
    mn --controller=remote,ip=127.0.0.1,port=6633 --custom mytopo.py --topo mytopo --switch ovsk,protocols=OpenFlow13 --mac
    ````

  * xterm发送数据包

    mininet中打开xterm窗口，在窗口运行构造发送数据包脚本

    ```
    xterm hx
    python hx_create.py
    ```

  * 定时抓包

    进入classes目录，执行以下命令

    ```
    python catch.py
    ```

  * 开启后端接口

    进入项目目录下，执行以下命令

    ```
    python interface.py
    ```

    