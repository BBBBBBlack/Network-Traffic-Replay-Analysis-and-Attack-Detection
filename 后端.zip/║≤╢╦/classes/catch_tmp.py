import subprocess
import time

subprocess.run(['java', '-classpath', '/SDN/flask/jar/jnetpcap.jar:/SDN/flask/jar/tika-core-1.17.jar:/SDN/flask/jar/commons-io-2.5.jar:/SDN/flask/jar/commons-math3-3.5.jar:.:', 'cic/cs/unb/ca/ifm/Cmd'],text=True)
subprocess.call(["python", "/SDN/flask/ICNN/simple_test.py"])
