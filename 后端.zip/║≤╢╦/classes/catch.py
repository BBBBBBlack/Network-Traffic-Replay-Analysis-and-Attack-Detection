from scapy.all import *  
import subprocess
import time


def main():  
    sw_list = ['s5-eth1','s5-eth2','s6-eth1','s6-eth2','s7-eth1','s7-eth2','s8-eth1','s8-eth2']
    while True:
        print('开始抓包...')
        pkt = sniff(iface=sw_list, timeout=20)
        wrpcap("/SDN/flask/pcap/trace1.pcap", pkt)
        print('.pcap文件生成...')
        subprocess.run(['java', '-classpath', '/SDN/flask/jar/jnetpcap.jar:/SDN/flask/jar/tika-core-1.17.jar:/SDN/flask/jar/commons-io-2.5.jar:/SDN/flask/jar/commons-math3-3.5.jar:.:', 'cic/cs/unb/ca/ifm/Cmd'],text=True)
        print('.csv文件生成...')
        subprocess.run(["python", "/SDN/flask/ICNN/simple_test.py"])
        # 指定要删除的文件路径
        file_path = '/SDN/flask/csv/trace1.pcap_Flow.csv'
        # 检查文件是否存在
        if os.path.exists(file_path):
        # 删除文件
            # os.remove(file_path)
            print(f"文件 {file_path} 已被删除")
        else:
            print(f"文件 {file_path} 不存在")

  
if __name__ == "__main__":  
    main()
